var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "26",
        "ok": "26",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5185",
        "ok": "5185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "2040",
        "ok": "2040",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1549",
        "ok": "1549",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1830",
        "ok": "1830",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3232",
        "ok": "3232",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4784",
        "ok": "4784",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5165",
        "ok": "5165",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 9,
        "percentage": 35
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 17,
        "percentage": 65
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "1.529",
        "ok": "1.529",
        "ko": "-"
    }
},
contents: {
"req_google--launch--50770": {
        type: "REQUEST",
        name: "Google: Launch Website",
path: "Google: Launch Website",
pathFormatted: "req_google--launch--50770",
stats: {
    "name": "Google: Launch Website",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1750",
        "ok": "1750",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5106",
        "ok": "5106",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3284",
        "ok": "3284",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "850",
        "ok": "850",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3234",
        "ok": "3234",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3531",
        "ok": "3531",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4590",
        "ok": "4590",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5003",
        "ok": "5003",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 9,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.529",
        "ok": "0.529",
        "ko": "-"
    }
}
    },"req_github--launch--b850d": {
        type: "REQUEST",
        name: "GitHub: Launch Website",
path: "GitHub: Launch Website",
pathFormatted: "req_github--launch--b850d",
stats: {
    "name": "GitHub: Launch Website",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1377",
        "ok": "1377",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "5185",
        "ok": "5185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "3315",
        "ok": "3315",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1355",
        "ok": "1355",
        "ko": "-"
    },
    "percentiles1": {
        "total": "3349",
        "ok": "3349",
        "ko": "-"
    },
    "percentiles2": {
        "total": "3963",
        "ok": "3963",
        "ko": "-"
    },
    "percentiles3": {
        "total": "4941",
        "ok": "4941",
        "ko": "-"
    },
    "percentiles4": {
        "total": "5136",
        "ok": "5136",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 0,
        "percentage": 0
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 100
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.235",
        "ok": "0.235",
        "ko": "-"
    }
}
    },"req_github--login-w-ea806": {
        type: "REQUEST",
        name: "GitHub: Login with Username and Password",
path: "GitHub: Login with Username and Password",
pathFormatted: "req_github--login-w-ea806",
stats: {
    "name": "GitHub: Login with Username and Password",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "45",
        "ok": "45",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22",
        "ok": "22",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles1": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23",
        "ok": "23",
        "ko": "-"
    },
    "percentiles3": {
        "total": "40",
        "ok": "40",
        "ko": "-"
    },
    "percentiles4": {
        "total": "44",
        "ok": "44",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 4,
        "percentage": 100
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.235",
        "ok": "0.235",
        "ko": "-"
    }
}
    },"req_google--search--80686": {
        type: "REQUEST",
        name: "Google: Search Karate",
path: "Google: Search Karate",
pathFormatted: "req_google--search--80686",
stats: {
    "name": "Google: Search Karate",
    "numberOfRequests": {
        "total": "9",
        "ok": "9",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2305",
        "ok": "2305",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1126",
        "ok": "1126",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "692",
        "ok": "692",
        "ko": "-"
    },
    "percentiles1": {
        "total": "715",
        "ok": "715",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1713",
        "ok": "1713",
        "ko": "-"
    },
    "percentiles3": {
        "total": "2147",
        "ok": "2147",
        "ko": "-"
    },
    "percentiles4": {
        "total": "2273",
        "ok": "2273",
        "ko": "-"
    },
    "group1": {
        "name": "t < 800 ms",
        "count": 5,
        "percentage": 56
    },
    "group2": {
        "name": "800 ms < t < 1200 ms",
        "count": 0,
        "percentage": 0
    },
    "group3": {
        "name": "t > 1200 ms",
        "count": 4,
        "percentage": 44
    },
    "group4": {
        "name": "failed",
        "count": 0,
        "percentage": 0
    },
    "meanNumberOfRequestsPerSecond": {
        "total": "0.529",
        "ok": "0.529",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
